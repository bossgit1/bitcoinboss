Development moved to https://gitlab.com/blacknet-ninja

https://bitcoinboss.org/ aims to continue on bitcoinboss chain.
